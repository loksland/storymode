
const { utils, scaler }  = require(`storymode`);

const BTN_TINT_ON = 0x000000;
const BTN_TINT_OFF = 0xffffff;

/*
Usage:
```js
this.addArt('!fs_*', '!fullscreen_*');
import FullScreenBtn from './sprites/fullScreenBtn.js';
const fsBtn = FullScreenBtn.fromTx(this.psdID + '/' + 'fullscreen_btn');
this.addChild(fsBtn);
```
*/
export default class FullScreenBtn extends PIXI.Container {
  
  constructor(){   
     
    super();
    
  }
  
  // Called after PSD projection is applied
  init(){
    
    this.on('removed', this.dispose);   
  
    this.interactive = true;
    this.buttonMode = true;
          
    this.art.fs_hit.alpha = 0.0;
    
    this.icons = [this.art.fs_icon_0,this.art.fs_icon_1];
    
    if (!scaler.supportsFullScreen()){
      this.visible = false;
    } else {
      
      this.syncState();
      scaler.on('fullscreenchange', this.syncState, this);
      this.on('pointerdown', this.onPointerDown, this)
    } 
    
    this.btnTint = false;
    
  }
  
  set state(_state){
    this._state = _state;
    for (let i = 0; i < this.icons.length; i++){
      this.icons[i].visible = i == this._state;
    } 
  }
  
  get state(){
    return this._state;
  }
  
  onPointerDown(ev){
    
    this.on('pointerupoutside', this.onPointerUpOutside, this)
    this.on('pointerup', this.onPointerUp, this)
    this.btnTint = true;
    
  }
  
  clearPointerUpEvents(){
    
    this.off('pointerupoutside', this.onPointerUpOutside, this);
    this.off('pointerup', this.onPointerUp, this);
    
  }
  
  onPointerUp(){
    
    this.clearPointerUpEvents();
    this.btnTint = false;
    
    scaler.toggleFullScreen()
        
  }
  
  syncState(){ 
    
    this.state = scaler.isFullScreen() ? 1 : 0;
    
  }
  
  onPointerUpOutside(){
    this.clearPointerUpEvents();
    this.btnTint = false;
  }  
  
  set btnTint(on){
    for (let icon of this.icons){
      icon.tint = on ? BTN_TINT_ON : BTN_TINT_OFF;
    }
  }

  dispose(){
    
    scaler.off('fullscreenchange', this.syncState, this);
    
    this.off('removed',  this.dispose);
    
    this.icons = null;
    
    this 
    .off('pointerdown')
    .off('pointerupoutside')
    .off('pointerup')

  }
  
}