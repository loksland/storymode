
const { utils, scaler, sfx }  = require(`storymode`);

const BTN_TINT_ON = 0x000000;
const BTN_TINT_OFF = 0xffffff;

/*
Usage:
```js
import MusicBtn from './sprites/musicBtn.js';
this.addArt('!music_*');
const musicBtn = MusicBtn.fromTx(this.psdID + '/' + 'music_btn');
this.addChild(musicBtn);
```
*/
export default class MusicBtn extends PIXI.Container {
  
  constructor(){   
     
    super();
    
  }
  
  // Called after PSD projection is applied
  init(){
    
    this.on('removed', this.dispose);   
  
    this.art.music_hit.alpha = 0.0;
    
    this.icons = [this.art.music_icon_0,this.art.music_icon_1];
    
    this.alpha = 0.5;
    this.state = 0;
    
    if (!sfx.ready){
      sfx.on('ready', this.onSfxReady, this)
    } else {
      this.onSfxReady();
    }
    
    this.btnTint = false;
    
  }
  
  onSfxReady(){
    
    sfx.off('ready', this.onSfxReady, this)
    
    this.interactive = true;
    this.buttonMode = true;
    
    this.alpha = 1.0;
    this.syncState();
    
    this.on('pointerdown', this.onPointerDown, this)
    sfx.on('bgloop_enabled_change', this.syncState, this)
    
  }
  
  set state(_state){
    this._state = _state;
    for (let i = 0; i < this.icons.length; i++){
      this.icons[i].visible = i == this._state;
    } 
  }
  
  get state(){
    return this._state;
  }
  
  onPointerDown(ev){
    
    this.on('pointerupoutside', this.onPointerUpOutside, this)
    this.on('pointerup', this.onPointerUp, this)
    this.btnTint = true;
    
  }
  
  clearPointerUpEvents(){
    
    this.off('pointerupoutside', this.onPointerUpOutside, this);
    this.off('pointerup', this.onPointerUp, this);
    
  }
  
  onPointerUp(){
    
    this.clearPointerUpEvents();
    this.btnTint = false;
    
    sfx.toggleBgLoopEnabled();
        
  }
  
  syncState(){ 
    
    this.state = sfx.bgLoopEnabled ? 1 : 0;
    
  }
  
  onPointerUpOutside(){
    this.clearPointerUpEvents();
    this.btnTint = false;
  }  
  
  set btnTint(on){
    for (let icon of this.icons){
      icon.tint = on ? BTN_TINT_ON : BTN_TINT_OFF;
    }
  }

  dispose(){
    
    sfx.off('ready', this.onSfxReady, this)
    sfx.off('bgloop_enabled_change', this.syncState, this)
    this.off('removed',  this.dispose);
    
    this.icons = null;
    
    this 
    .off('pointerdown')
    .off('pointerupoutside')
    .off('pointerup')

  }
  
}