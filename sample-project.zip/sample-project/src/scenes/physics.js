const {Scene, utils, nav, scaler, ui, physics} = require(`storymode`);


let Engine = Matter.Engine,
    Render = Matter.Render,
    Runner = Matter.Runner,
    Bodies = Matter.Bodies,
    Composites = Matter.Composites,
    Composite = Matter.Composite,
    Constraint = Matter.Constraint,
    MouseConstraint = Matter.MouseConstraint,
    Mouse = Matter.Mouse,
    Body = Matter.Body;
    
export default class PhysicsScene extends Scene {
  
  constructor(sceneData){
    
    super(sceneData, 'physics.psd', 0x002c43); 
    
  }
  
  didLoad(ev){
    
    super.didLoad(ev)
    
    this.engine = Engine.create();
  
    this.jrender = new physics.JRender({ptsPerMeterFactor:0.5});
    this.jrunner = new physics.JRunner(this.engine, this.jrender, this.onRender.bind(this), {fixedTimestep: false});
    
    this.addArt();
    
    let bodies = [];
    
    const restitution = 1.0
    const friction = 0.1
    const density = 0.001;
    let balls = []
    for (let i = 0; i < 99; i++){
      if (this.art['ball_' + String(i)]){                
        balls.push(this.jrender.addCircle(this.art['ball_' + String(i)], {restitution: restitution, friction:friction, density:density}));
      } else {
        break;
      }
    }
    
    this.jrender.linkFor('ball_0').body.isStatic = true;
    
    balls[4].isStatic = true;
    bodies = bodies.concat(balls);
    Body.setAngularVelocity( balls[2], Math.PI/15*(Math.random() > 0.5 ? -1.0 : 1.0));
    //Body.setAngularVelocity( balls[0], Math.PI/15*(Math.random() > 0.5 ? -1.0 : 1.0));
    Body.setAngularVelocity( balls[5], Math.PI/15*(Math.random() > 0.5 ? -1.0 : 1.0));
    
    var interRope = Constraint.create({   
        bodyA: balls[4],
        bodyB: balls[2],
        pointA:{x:0.0,y:0.0},
        pointB:{x:0.0,y:0.0},
        stiffness: 0.1
    });
    bodies.push(interRope);
    
    let boxes = []
    for (let i = 0; i < 99; i++){
      if (this.art['box_' + String(i)]){
        boxes.push(this.jrender.addRect(this.art['box_' + String(i)], {isStatic: true, restitution:restitution}));
      } else {
        break;
      }
    }
    bodies = bodies.concat(boxes);
    
    // https://brm.io/matter-js/docs/classes/Mouse.html
    //pixiApp.resizeTo); //)document.body
    this.mouse = Mouse.create(this.jrender.mouseElement); // window.document.querySelector('canvas'));
    this.jrender.adjustMouseToStage(this.mouse);
    //this.updateMouseOnStageResize();
    
    let mouseConstraint = MouseConstraint.create(this.engine, {
        mouse: this.mouse,
        constraint: {
          stiffness: 0.2
        }
    });

    bodies.push(mouseConstraint);
    
    Composite.add(this.engine.world, bodies);
    
    if (true){
      let jwireframeRender =  new physics.JWireframeRender(this.mouse, {lineThickness:1.0, ptsPerMeterFactor: this.jrender.ptm});
      this.addChild(jwireframeRender); // Should be auto disposed on scene dispose
      this.jrunner.renders.push(jwireframeRender); // Attach to runner.render list
    }
    
    this.ready();
    
  }
  
  shouldReloadOnStageResize(stageW, stageH){
    
    for (let p in this.art){
      this.art[p].applyProj();
      //gsap.killTweensOf(this.art[p], 'x,y');
    }
    
    gsap.killTweensOf(this.jrender.linkFor('ball_0').dispo)
    this.jrender.linkFor('ball_0').syncToDispo();    
    
    this.jrunner.tick();
    
    this.jrender.adjustMouseToStage(this.mouse);
    
    //this.updateMouseOnStageResize();
    // this.jmatter.runner.tick();
    
    return false;
    
  }
  
  onRender(){
    
    
    
  }
  
  onBtn(btn){
    if (btn.name == 'back'){
      nav.openScene('home', false, 'pan:left');
    } else if (btn.name == 'next'){
      nav.openScene('physics', false, 'pan:right');
    }
    
  }
  
  onWillArrive(fromModal){
    
    super.onWillArrive(fromModal);
    
  }
  
  onDidArrive(fromModal){
  
    super.onDidArrive(fromModal);
    
    if (false){
      let delay = 0.3;
      this.engine.timing.timeScale = 1.0;
      let dur = 0.3;
      gsap.to(this.engine.timing, dur, {timeScale:0.0, ease:Sine.easeOut, delay:delay});
      delay += dur + 0.5;
      gsap.to(this.engine.timing, 0.3, {timeScale:1.0, ease:Sine.easeIn, delay:delay});
    }
    
    let link = this.jrender.linkFor('ball_0')
    link.autoSync = false;
    gsap.to(link.dispo, 1.0, {rotation: utils.degToRad(45.0), x:'-=' + String(240.0*0.5*scaler.scaleFactor), y:'+=' + String(250.0*0.5*scaler.scaleFactor), ease:Power3.easeInOut, onUpdate:()=>{
      link.syncToDispo();      
    }})
    
    this.jrunner.resumeTick();
    
  }
  
  onWillExit(fromModal){
    
    super.onWillExit(fromModal);
    
  }
  
  onDidExit(fromModal){
    
    super.onDidExit(fromModal);
    this.jrunner.pauseTick();
    
  }
  
  // Clean up
  // --------
  
  dispose(){
    
    this.jrender.dispose();
    this.jrender = null;
    
    this.jrunner.dispose();
    this.jrunner = null;
    
    // Do dispose 1st 
    Matter.World.clear(this.engine.world);
    Matter.Engine.clear(this.engine);
    this.mouse = null;
    
    super.dispose();
    
  }
    
}
