const {Scene, utils, nav, scaler, ui} = require(`storymode`);



export default class Test extends Scene {
  
  constructor(sceneData){
    
    super(sceneData, 'test.psd', 0x002c43); 
    
    
    
  }
  
  didLoad(ev){
    
    super.didLoad(ev)
    
    this.addArt();
    
    
    gsap.fromTo(this.art.arm, 5.0, {rotation:0.0},{rotation:utils.degToRad(360.0), ease:Linear.easeNone, delay:0.0, repeat:-1});
    
    gsap.fromTo(this.art.ball_a, 2.0, {x:this.art.ball_a.x},{x:this.art.ball_a.x+100.0*scaler.scaleFactor, ease:Power2.easeInOut, delay:0.0, yoyo:true, repeat:-1});
    
    gsap.fromTo(this.art.ball_c, 2.0, {pixi:{scale:this.art.ball_a.scale.x}},{pixi:{scale:this.art.ball_a.scale.x*1.5}, ease:Power2.easeInOut, delay:0.0, yoyo:true, repeat:-1});
    
    this.ready();
    
  }
  
  shouldReloadOnStageResize(stageW, stageH){
    
    // console.log(scaler.scaleFactor, scaler.uiScaleFactor)
    
    gsap.killTweensOf(this.art.ball_c);
    
    for (let p in this.art){
      this.art[p].applyProj();
      gsap.killTweensOf(this.art[p], 'x,y');
    }
    
    return false;
    
  }
      
  onBtn(btn){
    
    
    
  }
  
  onWillArrive(fromModal){
    
    super.onWillArrive(fromModal);
    
    this.resumeTick();
    
  }
  
  onDidArrive(fromModal){
  
    super.onDidArrive(fromModal);
      
  }
  
  pauseTick(){
    ticker.remove(this.tick, this);
  }

  resumeTick(){
    this.pauseTick();
    ticker.add(this.tick, this);
  }

  tick(dt){
    
  }
  
  onWillExit(fromModal){
    
    super.onWillExit(fromModal);
    
    
  }
  
  onDidExit(fromModal){
    
    super.onDidExit(fromModal);
    this.pauseTick();
    
  }
  
  // Clean up
  // --------
  
  dispose(){
    
    // Do dispose 1st 

    super.dispose();
    
  }
    
}


