const {Scene, scaler, utils, nav} = require(`storymode`);

export default class Filter extends Scene {
    
  constructor(sceneData){
    
    super(sceneData, 'filter.psd', 0x444444); 
    
  }
  
  didLoad(ev){
    
    super.didLoad(ev)
    
    this.addArt();
        
    
    this.art.debugScreenBounds = new Graphics();
    this.addChild(this.art.debugScreenBounds);
    this.renderBgScreenBounds();
    
    this.art.net = new Graphics();
    this.addChild(this.art.net);
    
    this.art.net.filters = [new PIXI.filters.BevelFilter({thickness:4.0*0.5*scaler.scaleFactor})]
    
    this.renderNet();
    
    this.emitter = new PIXI.particles.Emitter(

        // The PIXI.Container to put the emitter in
        // if using blend modes, it's important to put this
        // on top of a bitmap, and not use the root stage Container
        this,
        [this.art.dot.texture],
        // Emitter configuration, edit this to change the look
        // of the emitter
        {
        	"alpha": {
        		"start": 1,
        		"end": 0
        	},
        	"scale": {
        		"start": 0.1,
        		"end": 0.01,
        		"minimumScaleMultiplier": 1
        	},
        	"color": {
        		"start": "#e4f9ff",
        		"end": "#3fcbff"
        	},
        	"speed": {
        		"start": 200,
        		"end": 50,
        		"minimumSpeedMultiplier": 1
        	},
        	"acceleration": {
        		"x": 0,
        		"y": 0
        	},
        	"maxSpeed": 0,
        	"startRotation": {
        		"min": 0,
        		"max": 360
        	},
        	"noRotation": false,
        	"rotationSpeed": {
        		"min": 0,
        		"max": 0
        	},
        	"lifetime": {
        		"min": 0.2,
        		"max": 0.8
        	},
        	"blendMode": "normal",
        	"frequency": 0.001,
        	"emitterLifetime": -1,
        	"maxParticles": 500,
        	"pos": {
        		"x": 0,
        		"y": 0
        	},
        	"addAtBack": false,
        	"spawnType": "circle",
        	"spawnCircle": {
        		"x": 0,
        		"y": 0,
        		"r": 0
        	}
        }
    );
    
    // new PIXI.filters.BevelFilter();
    //this.art.net.mask = this.art.range
    
    this.ready();
    
  }
  
  
  pauseTick(){
    this.emitter.emit = false;
    ticker.remove(this.tick, this);
  }

  resumeTick(){
    this.pauseTick();
    this.emitter.emit = true;
    ticker.add(this.tick, this);
  }

  tick(dt){
    // The emitter requires the elapsed
    // number of seconds since the last update
    this.emitter.update(dt*(1.0/60.0));
    
  }
  
  renderNet(){
    
    this.art.net.clear()
    
    let dims = {w:this.art.range.width, h:this.art.range.height}
    let pos = {x:this.art.range.x-dims.w*0.5, y:this.art.range.y-dims.h*0.5}
    this.art.net.lineStyle({width: 8.0*0.5*scaler.scaleFactor, color: 0xff33300, alpha: 1.0, cap:'round', join:'round'});
    
    const netSteps = 4; // make even
    
    this.art.net.moveTo(pos.x, pos.y);
    for (let i = 0; i < netSteps; i++){
      this.art.net.lineTo(pos.x+(dims.w/netSteps)*(i+1), pos.y+(dims.h*((i+1)%2)));
    }
    this.art.net.lineTo(pos.x+dims.w, pos.y+dims.h);
    for (let i = 0; i < netSteps; i++){
      this.art.net.lineTo(pos.x+dims.w-(dims.w/netSteps)*(i+1), pos.y+(dims.h*(i%2)));
    }
    this.art.net.closePath();
    
    // this.art.net.filterArea = new PIXI.Rectangle(pos.x,pos.y,dims.w,dims.h)
    
    //this.art.net.x += dims.w*0.5;
    
  }
  
  renderBgScreenBounds(){
    
    this.art.debugScreenBounds.clear()
    this.art.debugScreenBounds.lineStyle({width: 10.0*0.5*scaler.scaleFactor, color: 0xffffff, alpha: 1.0, cap:'round', join:'round'});
    this.art.debugScreenBounds.drawRect(this.bgScreen.x, this.bgScreen.y, this.bgScreen.width, this.bgScreen.height);
    
  }
  
  shouldReloadOnStageResize(stageW, stageH){

    for (let p in this.art){
      if (this.art[p].txInfo){
        this.art[p].applyProj();
      }
    }
    this.renderNet();
    this.renderBgScreenBounds();
    return false;
    
  }
      
  onBtn(btn){

    if (btn.name == 'next'){
      //this.art.net.cacheAsBitmap = true
      nav.openScene('filter', false, 'pan:right')
    }
    
  }
  
  onWillArrive(fromModal){
    
    super.onWillArrive(fromModal);
    
  }
  
  onDidArrive(fromModal){
  
    super.onDidArrive(fromModal);
      
    this.bgScreen.on('pointerdown', this.onPointerDown, this);
    this.resumeTick()
  }
  
  onPointerDown(ev){
    this.bgScreen.on('pointermove', this.onPointerMove, this);
    this.bgScreen.on('pointerup', this.onPointerUp, this);
    this.bgScreen.on('pointerupoutside', this.onPointerUp, this);
  }
  
  onPointerMove(ev){
    let pos = ev.data.getLocalPosition(this.parent);
    this.emitter.updateSpawnPos(pos.x,pos.y)
  }
  
  onPointerUp(){
    this.bgScreen.off('pointermove', this.onPointerMove, this);
    this.bgScreen.off('pointerup', this.onPointerUp, this);
    this.bgScreen.off('pointerupoutside', this.onPointerUp, this);
  }
  
  onWillExit(fromModal){
    
    super.onWillExit(fromModal);
    
    this.bgScreen.off('pointerdown', this.onPointerDown, this);
    this.pauseTick()
  }
  
  onDidExit(fromModal){
    
    super.onDidExit(fromModal);
    
  }
  
  
  // Clean up
  // --------
  
  dispose(){
    
    super.dispose();
    
  }
    
}


