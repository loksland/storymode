const {Scene, utils, nav, scaler, sfx} = require(`storymode`);

import Ball from './../sprites/ball.js';

export default class Cam extends Scene {
    
  static getSfxResources(){
    
    return {      
      pluck: 'audio/pluck.mp3'
    };
                      
  }
  
    constructor(sceneData){
      
      super(sceneData, 'cam.psd', 0x012f49, true); 
      
    }
    
    didLoad(ev){
      
      super.didLoad(ev)
      
      this.addArt('!ball*')
      
      
      const bg = new Graphics();
      bg.beginFill(0x000000);
      bg.drawRect(0,0,scaler.stageW,scaler.stageH);
      bg.endFill();
      this.camera.addChild(bg)

      this.balls = [];
      while(this.balls.length < 10){
        let ball = Ball.fromTx(this.psdID + '/ball');
        this.camera.addChild(ball);
        this.balls.push(ball);
      }
      
      this.art.ball_focus = Sprite.fromTx(this.psdID + '/ball_focus');
      this.camera.addChild(this.art.ball_focus);
      this.art.ball_focus.alpha = 0.5;
      
      this.ready();
      
    }
    
    shouldReloadOnStageResize(stageW, stageH){
  
      return true;
      
    }
        
    onBtn(btn){
      
      sfx.playSFX('pluck');
      nav.openScene('home', false, 'fade')
      
    }
    
    onWillArrive(fromModal){
      
      super.onWillArrive(fromModal);
      
      this.resumeTick();
      
      this.trackBallIndex = 0;
      this.camera.track(this.balls[this.trackBallIndex], false)
      
    }
    
    onDidArrive(fromModal){
    
      super.onDidArrive(fromModal);
        
      this.bgScreen.on('pointerup', this.nextTrack, this);  
    }
    
    
    nextTrack(){
      
      this.trackBallIndex++;
      if (this.trackBallIndex == this.balls.length){
        this.trackBallIndex = 0;
      }
      this.camera.track(this.balls[this.trackBallIndex], false)
      
    }
    
    pauseTick(){
      ticker.remove(this.tick, this);
    }

    resumeTick(){
      this.pauseTick();
      ticker.add(this.tick, this);
    }

    tick(dt){
      
      for (let ball of this.balls){
        ball.tick(dt)
      }
      
      this.art.ball_focus.position.copyFrom(this.balls[this.trackBallIndex])
      
      
    }
    
    onWillExit(fromModal){
      
      super.onWillExit(fromModal);
    
      this.bgScreen.off('pointerup', this.nextTrack, this);  
    }
    
    onDidExit(fromModal){
      
      this.pauseTick();
      super.onDidExit(fromModal);
       
    }
    
    // Clean up
    // --------
    
    dispose(){
      
      // Do dispose 1st 
      this.balls = null;
      
      console.log('cAM KILL')
      
      super.dispose();
      
    }
    
}


