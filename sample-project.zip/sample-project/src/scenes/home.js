const {Scene, utils, nav, sfx, store} = require(`storymode`);

import Ball from './../sprites/ball.js';

export default class Home extends Scene {
    
  static getSfxResources(){
    
    return {      
      pluck: 'audio/pluck.mp3'
    };
                      
  }

  constructor(sceneData){
    
    super(sceneData, 'home.psd', 0x012f49); 
    
  }
  
  didLoad(ev){
    
    super.didLoad(ev)
    
    this.addArt('!ball');
    
    this.balls = [];
    while(this.balls.length < 3){
      let ball = Ball.fromTx(this.psdID + '/ball');
      this.addChild(ball);
      this.balls.push(ball);
    }
  
    this.ready();
    
  }
  
  shouldReloadOnStageResize(stageW, stageH){

    return true;
    
  }
      
  onBtn(btn){
    
    sfx.playSFX('pluck');
    
    if (btn.name == 'start'){
      let trans = ['pan:up','pan:down','pan:left','pan:right','parallax:up','parallax:down','parallax:left','parallax:right','fade','pixelate','mario'];
      trans = ['fade'] 
       trans = ['pixelate']
      nav.openScene('home', false, trans[Math.floor(Math.random()*trans.length)]);
    } else if (btn.name == 'cam'){
      nav.openScene('cam', false, 'fade');
    } else if (btn.name == 'phys'){
      nav.openScene('physics', false, 'pan:right');
    } else {
      nav.openScene('popup', true, 'over');
    }
    
  }
  
  onWillArrive(fromModal){
    
    super.onWillArrive(fromModal);
    
    this.resumeTick();
    
  }
  
  onDidArrive(fromModal){
  
    super.onDidArrive(fromModal);
      
    this.spinArms();
    
  }
  
  spinArms(mod = true){
    
    let delay = 0.0;
    let dur = 1.0;
    
    let ang = mod ? 90.0 + (90.0 * Math.round(Math.random()*3)) : 0.0;
    
    let ease = Power2.easeOut;
    gsap.to(this.art.limb_a, dur, {rotation: utils.degToRad(ang), ease:ease, delay: delay})
    delay+=dur;
    
    gsap.to(this.art.limb_a.art.limb_b, dur, {rotation: utils.degToRad(ang), ease:ease, delay: delay})
    delay+=dur;
    
    gsap.to(this.art.limb_a.art.limb_b.art.limb_c, dur, {rotation: utils.degToRad(ang), ease:ease, delay: delay})
    delay+=dur;
    
    utils.wait(this, delay, this.spinArms, [!mod]);
    
  }
  
  pauseTick(){
    ticker.remove(this.tick, this);
  }

  resumeTick(){
    this.pauseTick();
    ticker.add(this.tick, this);
  }

  tick(dt){
    
    for (let ball of this.balls){
      ball.tick(dt)
    }
    
  }
  
  onWillExit(fromModal){
    
    super.onWillExit(fromModal);
    utils.killWaitsFor(this.spinArms)
    
  }
  
  onDidExit(fromModal){
    
    this.pauseTick();
    super.onDidExit(fromModal);
    
  }
  
  getMarioTransFocusRad(){
    
    return this.art.start.width;
    
  }
  
  getMarioTransPt(isIncoming){
    
    if (isIncoming){
      return this.art.title_guide.position.clone();        
    } else {
      return this.art.start.position.clone();        
    }
    
  }
  
  // Clean up
  // --------
  
  dispose(){
    
    console.log('home dispose')
    
    // Do dispose 1st 
    this.balls = null;
    
    super.dispose();
    
  }
    
}


