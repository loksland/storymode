const {Scene, utils, nav, sfx} = require(`storymode`);

export default class Popup extends Scene {
    
  static getSfxResources(){
    
    return {      
      pluck: 'audio/pluck.mp3'
    };
                      
  }
  
    constructor(sceneData){
      
      super(sceneData, 'popup.psd', 0x000000); 
      
    }
    
    didLoad(ev){
      
      super.didLoad(ev)
      
      this.addArt();
      
      this.art.close_btn.makeBtn(this.dismiss.bind(this));
      
      this.ready();
      
    }
    
    shouldReloadOnStageResize(stageW, stageH){
  
      return true;
      
    }
        
    onBtn(btn){
      
      sfx.playSFX('pluck');
      nav.openScene('popup', false, 'pan:right');
      
    }
    
    dismiss(){
      sfx.playSFX('pluck');
      nav.dismissScene();
      
    }
    
    onWillArrive(fromModal){
      
      super.onWillArrive(fromModal);
      
    }
    
    onDidArrive(fromModal){
    
      super.onDidArrive(fromModal);
        
      this.bgScreen.on('pointerdown', this.onBgPointerDown, this);
      
    }
    
    onBgPointerDown(ev){
      
      this.onBgPointerMove(ev);
      this.bgScreen.on('pointermove', this.onBgPointerMove, this);
      this.bgScreen.on('pointerup', this.onBgPointerUp, this);
      
    }
    
    onBgPointerMove(ev){
      let pos = ev.data.getLocalPosition(this.parent);
      this.art.parrot.rotation = utils.angleRadsBetweenPoints(pos, this.art.parrot.position) - utils.degToRad(90.0)
    }
    
    onBgPointerUp(ev){
      this.cancelDrag();
    }
    
    cancelDrag(){
      this.bgScreen.off('pointermove', this.onBgPointerMove, this);
      this.bgScreen.off('pointerup', this.onBgPointerUp, this);
    }
    
    onWillExit(fromModal){
      
      this.cancelDrag();
      this.bgScreen.off('pointerdown', this.onBgPointerDown, this);
      super.onWillExit(fromModal);
      
    }
    
    onDidExit(fromModal){
      
      super.onDidExit(fromModal);
      
    }
    
    // Clean up
    // --------
    
    dispose(){
      
      super.dispose();
      
    }
    
}


