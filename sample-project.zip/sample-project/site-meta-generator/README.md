
# Favicon Builder

This script requires:
 - Choppy (global npm module)
 - ImageMagick convert (installed via brew)

Reference:
 - https://html5boilerplate.com/
 - https://github.com/audreyfeldroy/favicon-cheat-sheet
 - https://mathiasbynens.be/notes/touch-icons

### Usage:

0. Delete `out` directory (optional)
1. Copy this directory into project.
2. Edit `favicon.psd` and run `generate.command`

- - -

### Web App Manifest (optional)

HTML5 Boilerplate includes a simple web app manifest file.

The web app manifest is a simple JSON file that allows you to control how your
app appears on a device's home screen, what it looks like when it launches in
that context and what happens when it is launched. This allows for much greater`
control over the UI of a saved site or web app on a mobile device.

It's linked to from the HTML as follows:

```html
<link rel="manifest" href="site.webmanifest">
```

Our
[site.webmanifest](https://github.com/h5bp/html5-boilerplate/blob/master/src/site.webmanifest)
contains a very skeletal "app" definition, just to show the basic usage. You
should fill this file out with [more information about your site or
application](https://developer.mozilla.org/en-US/docs/Web/Manifest)

### Favicons and Touch Icon

The shortcut icons should be put in the root directory of your site.
`favicon.ico` is automatically picked up by browsers if it's placed in the root.
HTML5 Boilerplate comes with a default set of icons (include favicon and one
Apple Touch Icon) that you can use as a baseline to create your own.

Please refer to the more detailed description in the [Extend section](extend.md)
of these docs.

- - -

### browserconfig.xml

This file contains all settings regarding custom tiles for IE11 and Edge.

For more info on this topic, please refer to [Microsoft's
Docs](https://docs.microsoft.com/en-us/previous-versions/windows/internet-explorer/ie-developer/platform-apis/dn320426(v=vs.85)).

- - -

### Open Graph Metadata 1/2

The [Open Graph Protocol](https://ogp.me/) allows you to define the way your
site is presented when referenced on third party sites and applications
(Facebook, Twitter, LinkedIn). The protocol provides a series of meta elements
that define the details of your site. The required attributes define the title,
preview image, URL, and [type](https://ogp.me/#types) (e.g., video, music,
website, article).

``` html
<meta property="og:title" content="">
<meta property="og:type" content="">
<meta property="og:url" content="">
<meta property="og:image" content="">
```

In addition to these four attributes there are many more attributes you can use
to add more richness to the description of your site. This just represents the
most basic implementation.

To see a working example, the following is the open graph metadata for the HTML5
Boilerplate site. In addition to the required fields we add `og:description` to
describe the site in more detail.

``` html
<meta name="og:url" content="https://html5boilerplate.com/">
<meta name="og:title" content="HTML5 ★ BOILERPLATE">
<meta name="og:type" content="website">
<meta name="og:description" content="The web’s most popular front-end template which helps you build fast, robust, and adaptable web apps or sites.">
<meta name="og:image" content="https://html5boilerplate.com/icon.png">
```

#Open graph meta tags 2/2

Included in HTML5 boilerplate: 

```html 
<meta property="og:title" content="">
<meta property="og:type" content="">
<meta property="og:url" content="">
<meta property="og:image" content="">
```

**og:title**
`<meta property="og:title" content="Open Graph Meta Tags: Everything You Need to Know" />`
The title of your page.
- Add it to all “shareable” pages.
- Focus on accuracy, value, and click-ability.
- Keep it short to prevent overflow. There’s no official guidance on this, but 40 characters for mobile and 60 for desktop is roughly the sweet spot.
- Use the raw title. Don’t include branding (e.g., your site name).

**og:url**
The URL of the content.
`<meta property="og:url" content="https://ahrefs.com/blog/open-graph-meta-tags/" />`
- Use the canonical URL. It helps consolidate all connected data, such as likes, across all the duplicate URLs posted.

**og:image**
`<meta property="og:image" content="https://ahrefs.com/blog/wp-content/uploads/2020/01/fb-open-graph-1.jpg" />`
The URL of an image for the social snippet.
Note that this is perhaps **the most essential Open Graph tag** because it occupies the most social feed real estate.
- Use custom images for “shareable” pages (e.g., homepage, articles, etc.)
- Use your logo or any other branded image for the rest of your pages.
- Use images with a 1.91:1 ratio and minimum recommended dimensions of 1200x630 for optimal clarity across all devices.

**og:type**  
The type of object you’re sharing. (e.g., article, website, etc.)
- Use `article` for articles and `website` for the rest of your pages.
- There is the option to describe object types further where appropriate (optional).

**og:description**
A brief description of the content. Also use the same content for: `<meta name="description" content="">`
```
<meta property="og:description" content="Learn about 13 features that set Ahrefs apart from the competition." />
```
- Complement the title to make the snippet as appealing and click-worthy as possible.
- Copy your meta description here if it makes sense.
- Keep it short and sweet. Facebook recommends 2–4 sentences, but that often truncates.

**og:locale**
`<meta property="og:locale" content="en_GB" />`
Use only for content not written in American English (en_US). Facebook assumes content without this tag is written in this language.

Guide:
https://ahrefs.com/blog/open-graph-meta-tags/