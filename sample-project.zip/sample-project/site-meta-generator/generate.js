#! /usr/bin/env node
console.log('');
console.log('Generate Site Meta');
console.log('==================');
console.log('');


const path = require('path');
const fs = require('fs');
const execSync = require('child_process').execSync;

const OUT_IMG_TMP_DIR_NAME = '_tmp';
const OUT_IMG_TMP_DIR =  path.join('.','out', OUT_IMG_TMP_DIR_NAME);
const OUT_ICO_FILENAME = 'favicon.ico'
const OUT_DIR = path.join('.','out');
const OUT_ICO = path.join(OUT_DIR, OUT_ICO_FILENAME);

const PSD_ABS_PATH = path.join(__dirname, 'favicon.psd')
const ICO_FILENAMES = ['favicon-16.png','favicon-32.png','favicon-48.png']
const ICO_IMGS = ['icon.png','tile-wide.png','tile.png'];

// const OUT_INDEX = path.join(OUT_DIR, 'index.html');

const BOOTSTRAP_DIR = path.join('.','boilerplate-src', 'html5-boilerplate_v8.0.0');
const BOOTSTRAP_ASSETS = ['index.html','robots.txt','browserconfig.xml','site.webmanifest'];

if (!fs.existsSync(PSD_ABS_PATH)){
  throw new Error('Invalid PSD_ABS_PATH `'+PSD_ABS_PATH+'`');
}

if (!fs.existsSync(BOOTSTRAP_DIR)){
  throw new Error('Invalid BOOTSTRAP_DIR `'+BOOTSTRAP_DIR+'`');
}


if (fs.existsSync(OUT_DIR)){
  try {
      fs.rmdirSync(OUT_DIR, { recursive: true });
  } catch (err) {
      console.error(`Error while deleting ${OUT_DIR}.`);
      throw Error();
  }
}


console.log('- Running choppy on `'+PSD_ABS_PATH+'`...');
let choppyCmd = 'choppy "'+PSD_ABS_PATH+'"';
execSync(choppyCmd);


if (!fs.existsSync(OUT_IMG_TMP_DIR) || !fs.statSync(OUT_IMG_TMP_DIR).isDirectory()){
  throw new Error('Invalid OUT_IMG_TMP_DIR `'+OUT_IMG_TMP_DIR+'`');
}

// convert favicon-16.png favicon-32.png favicon.ico

let icoSrcPaths = [];
for (let icoFilename of ICO_FILENAMES){
  let icoSrcPath = path.join(OUT_IMG_TMP_DIR, icoFilename);
  if (!fs.existsSync(icoSrcPath)){
    throw new Error('Invalid icoSrcPath `'+icoSrcPath+'`');
  }
  icoSrcPaths.push(icoSrcPath);
}

let convertCmd = 'convert ' +'"'+icoSrcPaths.join('" "')+'"'+' "'+OUT_ICO+'"';
execSync(convertCmd);

if (fs.existsSync(OUT_ICO)){
  console.log('- Created '+OUT_ICO_FILENAME+' containing ('+ICO_FILENAMES.join(',')+').');
} else {
  throw new Error('Failed to create OUT_ICO `'+OUT_ICO+'`');
}

for (let icoFilename of icoSrcPaths){
  try {
    fs.unlinkSync(icoFilename)
    //file removed
  } catch(err) {
    console.error(err)
  }
}

// Move touch icons

for (let icoImgName of ICO_IMGS){
  let icoImgPath = path.join(OUT_IMG_TMP_DIR, icoImgName);
  let icoImgPathOut = path.join(OUT_DIR, icoImgName);
  try {
    fs.renameSync(icoImgPath,icoImgPathOut)
    console.log('- Saved icon img to `'+icoImgPathOut+'` OK.');
    //file removed
  } catch(err) {
    console.error(err)
  }
}

if (fs.existsSync(OUT_IMG_TMP_DIR)){
  try {
      fs.rmdirSync(OUT_IMG_TMP_DIR, { recursive: true });
  } catch (err) {
      console.error(`Error while deleting ${OUT_IMG_TMP_DIR}.`);
      throw Error();
  }
}


// Copy selected bootstrap assets 

for (let bootstrapAsset of BOOTSTRAP_ASSETS){
  let assetIn = path.join(BOOTSTRAP_DIR, bootstrapAsset);
  let assetOut = path.join(OUT_DIR, bootstrapAsset);
  try {
    fs.copyFileSync(assetIn,assetOut)
    console.log('- Saved bootstrap asset to `'+assetOut+'` OK.');
    //file removed
  } catch(err) {
    console.error(err)
  }
  
}

console.log('');
