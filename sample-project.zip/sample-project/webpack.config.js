const path = require('path');
const { merge } = require('webpack-merge'); // Allows merging common config with target specific settings in a single file
const TARGET = process.env.npm_lifecycle_event;


var common = {
  entry: './src/app.js',
  output: {
      filename: 'app.js',
      path: path.resolve(__dirname, 'bin/js'),
      publicPath: '/js/',  
      libraryTarget: 'umd',
		  umdNamedDefine: true,
      // See: https://webpack.js.org/configuration/output/#outputenvironment  
      environment: {
        // The environment supports arrow functions ('() => { ... }').
        arrowFunction: false,
        // The environment supports BigInt as literal (123n).
        bigIntLiteral: false,
        // The environment supports const and let for variable declarations.
        const: false,
        // The environment supports destructuring ('{ a, b } = obj').
        destructuring: false,
        // The environment supports an async import() function to import EcmaScript modules.
        dynamicImport: false,
        // The environment supports 'for of' iteration ('for (const x of array) { ... }').
        forOf: false,
        // The environment supports ECMAScript Module syntax to import ECMAScript modules (import ... from '...').
        module: false
      }
  },
  // See: https://webpack.js.org/loaders/babel-loader/
  module: {
    rules: [
      {
        // Only run `.js` files through Babel
        test: /\.m?js$/,
        use: [
          {
            loader: 'babel-loader',
            options: {
              presets: [
              "@babel/preset-env",
              //{
              //  "useBuiltIns": "usage",
              //  "corejs": "3",
              //  "targets": {
              //    "browsers": ["ie 10"]
              //  }
              //}
            ]
            }
          }
        ],
      }
    ]
  }
};

//   xexclude: /(node_modules)/,

// Test 
 
if(TARGET === 'start:dev') {
  
  // See:
  // - https://webpack.js.org/configuration/dev-server/#devserverstatic
  // - https://github.com/webpack/webpack-dev-server/blob/master/CHANGELOG.md
  
  module.exports = merge(common, {
    devServer: {
      host: '0.0.0.0',
      port: '8080',
      open: true,
      static: {
        directory: path.resolve(__dirname, 'bin'),
        watch: {
          ignored: path.resolve(__dirname, 'bin','img'),
        },
      }
    }, 
    devtool: 'inline-source-map'
  });

} else if (TARGET === 'build') {

  module.exports = merge(common, {
    //  devtool: '' // 'source-map
    
  });
  
}



